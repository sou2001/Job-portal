# JobPortal

* An application which connects employer and job seekers where employers are the source of the resources and the job seeker can find and apply for their targeted job.
* Status of application can be tracked by the applicants, and recruiters can recruit applicants based on applicant profile and resume posted by them.
* Key Features include registration followed by email verification, adding multiple job profiles for recruiters, job search for applicants, track status of application and editable profile
